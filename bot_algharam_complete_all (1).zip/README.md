# بوت الغرام — Project Skeleton

هذا المشروع هو skeleton أساسي لبوت يقدم أرقام مؤقتة لاستقبال SMS. يحتوي على:
- backend (FastAPI skeleton)
- frontend (Next.js simple page)
- infra (docker-compose)

### تشغيل سريع (محلي)
1. ثبت Docker وDocker Compose.
2. من داخل /mnt/data/bot_algharam_skeleton/infra شغّل:
   - `docker-compose up --build`
3. الواجهة ستعمل على http://localhost:3000 والباكند على http://localhost:8000

> ملاحظة: هذا skeleton للأغراض التطويرية فقط. يلزم تنفيذ مزيد من العمل (قاعدة بيانات حقيقية، مخططات، أمان، تسجيل دخول، مزود أرقام واقعي...).



## Added Components
- SQLAlchemy models (backend/app/models.py)
- Async DB session (backend/app/db_session.py)
- Auth (register/login) stub (backend/app/api/v1/auth.py)
- OTP extractor util (backend/app/utils/otp.py)
- Twilio adapter stub (backend/app/providers/twilio_adapter.py)
- Admin and Billing endpoints stubs
- features.md with full feature list

To run tests:
```
# from backend folder (with pytest installed)
pytest
```


## Next Improvements Implemented
- DB-backed auth (JWT)
- Alembic migration skeleton
- Twilio & Stripe integration stubs (implement keys to use)
- WebSocket endpoint for notifications (/ws/notifications)
- Admin & Features pages in frontend

## New ENV variables needed
- STRIPE_API_KEY
- TWILIO_ACCOUNT_SID
- TWILIO_AUTH_TOKEN

