import os
# Placeholder Twilio adapter. For production, use twilio client and real REST calls.
class TwilioAdapter:
    def __init__(self, config=None):
        self.config = config or {}

    def purchase_number(self, country, type, duration_minutes):
        # Simulate purchasing: return fake provider id and number
        return {'provider_number_id': 'tw_demo_'+country, 'number': '+1 555 100 0000'}

    def release_number(self, provider_number_id):
        return True

    def parse_incoming(self, payload):
        # Twilio sends fields like 'From', 'To', 'Body'
        return {
            'from': payload.get('From'),
            'to': payload.get('To'),
            'body': payload.get('Body')
        }
