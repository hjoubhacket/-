from abc import ABC, abstractmethod

class BaseProvider(ABC):
    @abstractmethod
    def purchase_number(self, country, type, duration_minutes):
        pass

    @abstractmethod
    def release_number(self, provider_number_id):
        pass
