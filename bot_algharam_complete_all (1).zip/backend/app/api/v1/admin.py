from fastapi import APIRouter
router = APIRouter(prefix='/api/v1/admin')

@router.get('/health')
async def health():
    return {'ok': True, 'role': 'admin'}
