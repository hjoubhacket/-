from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, EmailStr
from passlib.context import CryptContext
from jose import jwt, JWTError
from datetime import datetime, timedelta
from ..models import User
from ..db_session import AsyncSessionLocal
from sqlalchemy.future import select
import os
import asyncio

pwd_context = CryptContext(schemes=['bcrypt'], deprecated='auto')
SECRET = os.getenv('JWT_SECRET', 'jwtsecret')
ACCESS_EXPIRE_MINUTES = 8*60

router = APIRouter(prefix='/api/v1/auth')

class RegisterIn(BaseModel):
    email: EmailStr
    password: str

class LoginIn(BaseModel):
    email: EmailStr
    password: str

async def get_user_by_email(email: str):
    async with AsyncSessionLocal() as session:
        q = await session.execute(select(User).where(User.email==email))
        return q.scalars().first()

@router.post('/register')
async def register(payload: RegisterIn):
    existing = await get_user_by_email(payload.email)
    if existing:
        raise HTTPException(status_code=400, detail='Email already registered')
    hashed = pwd_context.hash(payload.password)
    async with AsyncSessionLocal() as session:
        user = User(email=payload.email, password_hash=hashed)
        session.add(user)
        await session.commit()
        await session.refresh(user)
        return {'ok': True, 'id': str(user.id)}

@router.post('/login')
async def login(payload: LoginIn):
    user = await get_user_by_email(payload.email)
    if not user or not pwd_context.verify(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail='Invalid credentials')
    to_encode = {'sub': str(user.id), 'exp': datetime.utcnow() + timedelta(minutes=ACCESS_EXPIRE_MINUTES)}
    token = jwt.encode(to_encode, SECRET, algorithm='HS256')
    return {'access_token': token, 'token_type':'bearer'}
