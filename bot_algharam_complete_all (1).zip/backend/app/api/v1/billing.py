from fastapi import APIRouter
router = APIRouter(prefix='/api/v1/billing')

@router.get('/credits')
async def credits():
    # return demo credits
    return {'credits': 100, 'currency': 'USD'}
