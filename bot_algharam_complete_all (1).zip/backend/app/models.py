from sqlalchemy import Column, String, DateTime, Boolean, ForeignKey, Enum, JSON
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.ext.declarative import declarative_base
import enum
import uuid

Base = declarative_base()

class NumberStatus(enum.Enum):
    available = 'available'
    allocated = 'allocated'
    expired = 'expired'

class User(Base):
    __tablename__ = 'users'
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(String, default='user')
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    is_active = Column(Boolean, default=True)

class Provider(Base):
    __tablename__ = 'providers'
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String, nullable=False)
    type = Column(String, nullable=False)
    config = Column(JSON)

class Number(Base):
    __tablename__ = 'numbers'
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    provider_id = Column(UUID(as_uuid=True), ForeignKey('providers.id'))
    provider_number = Column(String, nullable=False)
    country = Column(String)
    type = Column(String)  # public/private
    status = Column(Enum(NumberStatus), default=NumberStatus.available)
    owner_user_id = Column(UUID(as_uuid=True), nullable=True)
    expires_at = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Message(Base):
    __tablename__ = 'messages'
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    number_id = Column(UUID(as_uuid=True), ForeignKey('numbers.id'))
    from_number = Column(String)
    body = Column(String)
    received_at = Column(DateTime(timezone=True), server_default=func.now())
    raw_payload = Column(JSON)
