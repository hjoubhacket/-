import re

# simple OTP extractor: finds 4-8 digit sequences often used as codes
def extract_otp(text: str):
    if not text:
        return None
    matches = re.findall(r'\b(\d{4,8})\b', text)
    if not matches:
        return None
    # prefer first match; in future add ML ranking
    return matches[0]
