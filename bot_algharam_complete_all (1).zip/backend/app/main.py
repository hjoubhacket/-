from fastapi import FastAPI, Request
from fastapi import APIRouter
from .api.v1 import auth as auth_router
from .utils.otp import extract_otp
from pydantic import BaseModel
import os
app = FastAPI(title="بوت الغرام - Backend (Skeleton)")

from .ws_manager import ConnectionManager
manager = ConnectionManager()
app.include_router(auth_router.router)
from .api.v1 import admin as admin_router
app.include_router(admin_router.router)
from .api.v1 import billing as billing_router
app.include_router(billing_router.router)

class RequestNumber(BaseModel):
    country: str
    type: str
    duration_minutes: int

@app.get("/")
async def root():
    return {"ok": True, "service": "بوت الغرام - backend skeleton"}

@app.post("/api/v1/numbers/request")
async def request_number(payload: RequestNumber):
    # This is a skeleton: in real app connect to providers and DB
    return {
        "number_id": "demo-id-123",
        "number": "+1 555 000 0000",
        "expires_at": "2025-12-31T23:59:59Z"
    }

@app.post("/api/v1/webhooks/sms/incoming")
async def sms_incoming(request: Request):
    payload = await request.json()
    # try to extract OTP automatically
    otp = extract_otp(payload.get('Body') or payload.get('body') or '')
    if otp:
        payload['extracted_otp'] = otp
    # validate signature / store message (not implemented in skeleton)
    return {"ok": True, "received": payload}


from fastapi import WebSocket

@app.websocket('/ws/notifications')
async def websocket_notifications(ws: WebSocket):
    await manager.connect(ws)
    try:
        while True:
            data = await ws.receive_text()
            # echo or keep-alive
            await ws.send_text(f'ack: {data}')
    except Exception:
        manager.disconnect(ws)
