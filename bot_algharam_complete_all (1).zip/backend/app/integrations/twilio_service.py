import os
# Twilio integration stub: shows how to use Twilio client. No network calls here.
# pip install twilio
def buy_number(country):
    # Example using twilio library:
    # from twilio.rest import Client
    # client = Client(account_sid, auth_token)
    # number = client.available_phone_numbers(country).local.list()[0]
    # purchased = client.incoming_phone_numbers.create(phone_number=number.phone_number, sms_url='https://yourdomain/webhook')
    # return purchased.sid, purchased.phone_number
    return {'sid':'TW_FAKE_SID','phone_number':'+1 555 200 0000'}

def parse_webhook(payload: dict):
    # Twilio posts 'From','To','Body'
    return {'from': payload.get('From'), 'to': payload.get('To'), 'body': payload.get('Body')}
