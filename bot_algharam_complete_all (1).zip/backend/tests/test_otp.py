def test_otp_extractor():
    from app.utils.otp import extract_otp
    assert extract_otp('Your code is 123456') == '123456'
    assert extract_otp('No code here') is None
