import React, {useState} from 'react'

export default function Home(){
  const [country, setCountry] = useState('US')
  const [number, setNumber] = useState<string|null>(null)

  async function requestNumber(){
    const res = await fetch('http://localhost:8000/api/v1/numbers/request', { 
      method: 'POST', 
      headers:{'Content-Type':'application/json'}, 
      body: JSON.stringify({country, type:'private', duration_minutes:60}) 
    })
    const data = await res.json()
    setNumber(data.number)
  }

  return (
    <div style={{padding:20,fontFamily:'Arial'}}>
      <h1>بوت الغرام — اطلب رقم مؤقت</h1>
      <select value={country} onChange={e=>setCountry(e.target.value)}>
        <option value="US">United States</option>
        <option value="GB">United Kingdom</option>
        <option value="MA">Morocco</option>
      </select>
      <button onClick={requestNumber} style={{marginLeft:10}}>اطلب رقم</button>
      {number && <div style={{marginTop:20}}>الرقم: <b>{number}</b></div>}
    </div>
  )
}
