import React from 'react'
import fs from 'fs'
import path from 'path'

export default function Features({features}){
  return (
    <div style={{padding:20,fontFamily:'Arial'}}>
      <h1>ميزات بوت الغرام</h1>
      <pre>{JSON.stringify(features,null,2)}</pre>
    </div>
  )
}

export async function getStaticProps(){
  const fpath = path.join(process.cwd(), '..', 'features.md')
  let features = 'Features file not found'
  try{
    features = fs.readFileSync(fpath, 'utf8')
  }catch(e){}
  return { props: { features } }
}
