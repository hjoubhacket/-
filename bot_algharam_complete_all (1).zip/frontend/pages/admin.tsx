import React from 'react'

export default function Admin(){
  return (
    <div style={{padding:20,fontFamily:'Arial'}}>
      <h1>Admin Panel (Demo)</h1>
      <p>Manage providers, numbers, users, and view reports here.</p>
    </div>
  )
}
